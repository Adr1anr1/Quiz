document.addEventListener("DOMContentLoaded", () => {
  const startPage = document.getElementById('start-page');
  const quizPage = document.getElementById('quiz-page');
  const resultPage = document.getElementById('result-page');
  const questionElement = document.getElementById('question');
  const optionsElement = document.getElementById('options');
  const timerElement = document.getElementById('time-left');
  const nextButton = document.getElementById('next-question');
  const scoreElement = document.getElementById('score');
  const highScoreElement = document.getElementById('high-score');
  const totalTimeElement = document.getElementById('total-time');
  const quizTotalTimeElement = document.getElementById('quiz-total-time');

  let currentQuestionIndex = 0, score = 0, highScore = 0;
  const quizTimeLimit = 10; // Tid per fråga
  let questions = [];
  let timer, questionStartTime, quizStartTime, quizTimer;

  // Hämta frågor från API beroende på ämne
  async function fetchQuestions(category) {
    const response = await fetch(`https://opentdb.com/api.php?amount=5&category=${category}&type=multiple`);
    const data = await response.json();
    return data.results.map(q => ({
      question: q.question,
      answers: [...q.incorrect_answers, q.correct_answer].sort(() => Math.random() - 0.5),
      correct: q.correct_answer
    }));
  }

  // Starta quiz för allmänbildning
  async function startGeneralKnowledgeQuiz() {
    startPage.classList.remove('active');
    quizPage.classList.add('active');
    score = 0;
    currentQuestionIndex = 0;
    questions = await fetchQuestions(9); // Allmänbildning kategori
    quizStartTime = Date.now();
    startQuizTimer();
    loadQuestion(questions[currentQuestionIndex]);
  }

  // Starta quiz för sport
  async function startSportsQuiz() {
    startPage.classList.remove('active');
    quizPage.classList.add('active');
    score = 0;
    currentQuestionIndex = 0;
    questions = await fetchQuestions(21); // Sport kategori
    quizStartTime = Date.now();
    startQuizTimer();
    loadQuestion(questions[currentQuestionIndex]);
  }

  function startQuizTimer() {
    quizTimer = setInterval(() => {
      const elapsedTime = Math.floor((Date.now() - quizStartTime) / 1000);
      quizTotalTimeElement.innerHTML = `Total tid: ${formatTime(elapsedTime)}`;
    }, 1000);
  }

  function formatTime(seconds) {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
  }

  function loadQuestion(question) {
    questionElement.innerHTML = question.question;
    optionsElement.innerHTML = '';
    nextButton.classList.add('hidden');

    question.answers.forEach(answer => {
      const button = document.createElement('button');
      button.innerHTML = answer;
      button.onclick = () => checkAnswer(button, question.correct);
      optionsElement.appendChild(button);
    });

    startQuestionTimer(question);
  }

  function startQuestionTimer(question) {
    let timeLeft = quizTimeLimit;
    timerElement.innerHTML = timeLeft;

    timer = setInterval(() => {
      timeLeft--;
      timerElement.innerHTML = timeLeft;
      if (timeLeft === 0) {
        clearInterval(timer);
        handleTimeOut(question);
      }
    }, 1000);
  }

  function disableOptions() {
    optionsElement.querySelectorAll('button').forEach(btn => {
      btn.disabled = true;
    });
  }

  function handleTimeOut(question) {
    disableOptions();
    optionsElement.querySelectorAll('button').forEach(btn => {
      if (btn.innerHTML === question.correct) {
        btn.style.backgroundColor = 'green';
      } else {
        btn.style.backgroundColor = 'red';
      }
    });
    nextButton.classList.remove('hidden');
  }

  function checkAnswer(button, correctAnswer) {
    clearInterval(timer);
    disableOptions();

    if (button.innerHTML === correctAnswer) {
      score++;
      button.style.backgroundColor = 'green';
    } else {
      button.style.backgroundColor = 'red';
      optionsElement.querySelectorAll('button').forEach(btn => {
        if (btn.innerHTML === correctAnswer) {
          btn.style.backgroundColor = 'green';
        }
      });
    }

    nextButton.classList.remove('hidden');
  }

  nextButton.onclick = () => {
    currentQuestionIndex++;
    if (currentQuestionIndex < questions.length) {
      loadQuestion(questions[currentQuestionIndex]);
    } else {
      endQuiz();
    }
  };

  function endQuiz() {
    clearInterval(quizTimer);
    const quizEndTime = Date.now();
    const totalQuizTime = Math.floor((quizEndTime - quizStartTime) / 1000);

    quizPage.classList.remove('active');
    resultPage.classList.add('active');
    scoreElement.innerHTML = score;
    highScore = Math.max(score, highScore);
    highScoreElement.innerHTML = highScore;
    totalTimeElement.innerHTML = `Total tid: ${formatTime(totalQuizTime)}`;

    localStorage.setItem('highScore', highScore);
  }

  document.getElementById('restart-quiz').onclick = () => {
    resultPage.classList.remove('active');
    startPage.classList.add('active');
  };

  // Starta quiz när användaren väljer ett ämne
  document.getElementById('start-general-knowledge').onclick = startGeneralKnowledgeQuiz;
  document.getElementById('start-sports').onclick = startSportsQuiz;
});
  